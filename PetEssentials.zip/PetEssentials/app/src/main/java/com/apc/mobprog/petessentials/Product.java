package com.apc.mobprog.petessentials;

import android.graphics.drawable.Drawable;

public class Product {

    public String productName;
    public Drawable productImage;
    public String productDescription;
    public double price;
    public boolean selected;

    public Product(String productName, Drawable productImage, String productDescription,
                   double price) {
        this.productName = productName;
        this.productImage = productImage;
        this.productDescription = productDescription;
        this.price = price;
    }

}
