package com.apc.mobprog.petessentials;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

import java.util.List;


public class ProductList extends Activity {

    ImageView productImage;
    private List<Product> productItemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        Intent intent = getIntent();
        AccessoriesOrToys(intent.getExtras().getInt("productType"));

        productItemList = CartHelper.getProducts(getResources(), intent.getExtras().getInt("productType"));

        ListView productItemListView = (ListView) findViewById(R.id.ProductListView);
        productItemListView.setAdapter(new ProductAdapter(productItemList, getLayoutInflater(), false));

        productItemListView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                Intent productDetailsIntent = new Intent(getBaseContext(),ProductOverview.class);
                productDetailsIntent.putExtra(CartHelper.PRODUCT_INDEX, position);
                startActivity(productDetailsIntent);
            }
        });

        Button viewCart = (Button) findViewById(R.id.ButtonViewCart);
        viewCart.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewCartIntent = new Intent(getBaseContext(), Cart.class);
                startActivity(viewCartIntent);
            }
        });

    }

    public void AccessoriesOrToys(Integer productType){

        productImage = (ImageView) findViewById(R.id.imgProductList);

        if (productType == 1){
            productImage.setImageResource(R.drawable.accessories);

        }else if (productType == 2){
            productImage.setImageResource(R.drawable.toys);
        }
    }

}
