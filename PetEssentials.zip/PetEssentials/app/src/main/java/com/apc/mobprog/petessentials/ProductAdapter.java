package com.apc.mobprog.petessentials;

import android.view.LayoutInflater;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import android.view.View;
import android.view.ViewGroup;


public class ProductAdapter extends BaseAdapter {

    private List<Product> ProductList;
    private LayoutInflater Inflater;
    private boolean ShowCheckbox;

    public ProductAdapter(List<Product> list, LayoutInflater inflater, boolean showCheckbox) {
        ProductList = list;
        Inflater = inflater;
        ShowCheckbox = showCheckbox;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewItem item;

        if (convertView == null) {
            convertView = Inflater.inflate(R.layout.productitem,
                    null);
            item = new ViewItem();

            item.productImageView = (ImageView) convertView
                    .findViewById(R.id.ImageViewItem);

            item.productTitle = (TextView) convertView.findViewById(R.id.TextViewItem);

            item.productCheckbox = (CheckBox) convertView.findViewById(R.id.CheckBoxSelected);

            convertView.setTag(item);
        } else {
            item = (ViewItem) convertView.getTag();
        }

        Product currentProduct = ProductList.get(position);

        item.productImageView.setImageDrawable(currentProduct.productImage);
        item.productTitle.setText(currentProduct.productName);

        if (!ShowCheckbox) {
            item.productCheckbox.setVisibility(View.GONE);
        } else {
            if (currentProduct.selected == true)
                item.productCheckbox.setChecked(true);
            else
                item.productCheckbox.setChecked(false);
        }


        return convertView;
    }

    @Override
    public int getCount() {
        return ProductList.size();
    }

    @Override
    public Object getItem(int position) {
        return ProductList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewItem {
        ImageView productImageView;
        TextView productTitle;
        CheckBox productCheckbox;
    }

}
