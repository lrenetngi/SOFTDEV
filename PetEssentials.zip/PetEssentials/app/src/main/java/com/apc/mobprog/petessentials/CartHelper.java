package com.apc.mobprog.petessentials;

import java.util.List;
import java.util.Vector;

import android.content.res.Resources;

public class CartHelper {

    public static final String PRODUCT_INDEX = "PRODUCT_INDEX";

    private static List<Product> productsList;
    private static List<Product> cartList;

    public static List<Product> getProducts(Resources res, Integer productType){
        if(productsList == null){

            productsList = new Vector<Product>();

            if(productType == 1){
                productsList.add(new Product("Purple Colar", res.getDrawable(R.drawable.purplecolar), "Purple Colar Description", 100));
                productsList.add(new Product("Dog Bed", res.getDrawable(R.drawable.dogbed), "Dog Bed Description", 200));
                productsList.add(new Product("Dog Carrier", res.getDrawable(R.drawable.dogcarrier), "Dog Carrier Description", 300));
                productsList.add(new Product("Leather Leash", res.getDrawable(R.drawable.leatherleash), "Leather Leash Description", 400));
            }
            if(productType == 2){
                productsList.add(new Product("Purple Colar", res.getDrawable(R.drawable.toy_1), "Toy 1 Description", 100));
                productsList.add(new Product("Dog Bed", res.getDrawable(R.drawable.toy_2), "Toy 2 Description", 200));
                productsList.add(new Product("Dog Carrier", res.getDrawable(R.drawable.toy_3), "Toy 3 Description", 300));
                productsList.add(new Product("Leather Leash", res.getDrawable(R.drawable.toy_4), "Toy 4 Description", 400));
            }
        }

        return productsList;
    }

    public static List<Product> getProduct(Resources res){
        if(productsList == null){

            productsList = new Vector<Product>();

            productsList.add(new Product("Purple Colar", res.getDrawable(R.drawable.purplecolar), "Purple Colar Description", 100));
            productsList.add(new Product("Dog Bed", res.getDrawable(R.drawable.dogbed), "Dog Bed Description", 200));
            productsList.add(new Product("Dog Carrier", res.getDrawable(R.drawable.dogcarrier), "Dog Carrier Description", 300));
            productsList.add(new Product("Leather Leash", res.getDrawable(R.drawable.leatherleash), "Leather Leash Description", 400));
            productsList.add(new Product("Purple Colar", res.getDrawable(R.drawable.toy_1), "Toy 1 Description", 100));
            productsList.add(new Product("Dog Bed", res.getDrawable(R.drawable.toy_2), "Toy 2 Description", 200));
            productsList.add(new Product("Dog Carrier", res.getDrawable(R.drawable.toy_3), "Toy 3 Description", 300));
            productsList.add(new Product("Leather Leash", res.getDrawable(R.drawable.toy_4), "Toy 4 Description", 400));

        }

        return productsList;
    }


    public static List<Product> getCart() {
        if(cartList == null) {
            cartList = new Vector<Product>();
        }
        return cartList;
    }

}
