package com.apc.mobprog.petessentials;

import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class Cart extends Activity {

    private List<Product> CartList;
    private ProductAdapter ProductAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        CartList = CartHelper.getCart();

        // Make sure to clear the selections
        for(int i=0; i<CartList.size(); i++) {
            CartList.get(i).selected = false;
        }

        // Create the list
        final ListView listViewCatalog = (ListView) findViewById(R.id.ProductListView);
        ProductAdapter = new ProductAdapter(CartList, getLayoutInflater(), true);
        listViewCatalog.setAdapter(ProductAdapter);

        listViewCatalog.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {

                Product selectedProduct = CartList.get(position);
                if(selectedProduct.selected == true)
                    selectedProduct.selected = false;
                else
                    selectedProduct.selected = true;

                ProductAdapter.notifyDataSetInvalidated();

            }
        });


        Button removeButton = (Button) findViewById(R.id.ButtonRemoveFromCart);
        removeButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // Loop through and remove all the products that are selected
                // Loop backwards so that the remove works correctly
                for(int i=CartList.size()-1; i>=0; i--) {

                    if(CartList.get(i).selected) {
                        CartList.remove(i);
                    }
                }
                ProductAdapter.notifyDataSetChanged();
            }
        });



    }
}
